MexApi. This is not an API
##########################
:date: 2013-08-29 07:55:02
:author: Deny Dias

Deny Dias personal weblog. Includes his blog (content sources, settings and static html), links to his social accounts and resume. This is not an API.

Check it out at: `mexapi.macpress.com.br <http://mexapi.macpress.com.br/>`_

MexApi is licensed under `CC0 http://creativecommons.org/publicdomain/zero/1.0/`_.